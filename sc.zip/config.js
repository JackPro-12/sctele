module.exports = {
  BOT_TOKEN: "7887587003:AAHVO_TQZoehri88ib43xbC373jyGDELfRU", // Token bot Telegram
  OWNER_ID: "7775351919", // ID pemilik bot
  allowedGroupIds: [-1002374857091], // ID grup yang diizinkan
};